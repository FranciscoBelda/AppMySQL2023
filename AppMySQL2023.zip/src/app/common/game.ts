export interface Game {

  id?: number;
  title: string;
  subtitle: string;
  description: string;
  image: string;
  favorite: boolean;
  created_at?: string;
}
